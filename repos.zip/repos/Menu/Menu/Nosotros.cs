﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Menu
{
    public partial class Nosotros : Form
    {
        private Form menuRef;

        public Nosotros(Form menu)
        {
            InitializeComponent();
            this.menuRef = menu;
        }

        // Previene que se cierre con la "X"
        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            if (e.CloseReason == CloseReason.UserClosing)
            {
                e.Cancel = true; // Cancela el cierre
            }
            base.OnFormClosing(e);
        }

        // Evento del botón "Atrás"
        private void button1_Click(object sender, EventArgs e)
        {
            menuRef.Show();  // Vuelve a mostrar el menú
            this.Dispose();  // Libera y cierra Nosotros
        }
        private void Nosotros_Load(object sender, EventArgs e)
        {
            // Puedes dejarlo vacío o poner configuración aquí si lo necesitas
        }

    }
}
