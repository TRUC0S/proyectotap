﻿using System.Windows.Forms;

namespace Registro
{
    partial class Registro
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Registro));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.enviar = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.blanco = new System.Windows.Forms.RadioButton();
            this.negro = new System.Windows.Forms.RadioButton();
            this.natural = new System.Windows.Forms.RadioButton();
            this.producto = new System.Windows.Forms.ComboBox();
            this.idcliente = new System.Windows.Forms.TextBox();
            this.nombre = new System.Windows.Forms.TextBox();
            this.apaterno = new System.Windows.Forms.TextBox();
            this.amaterno = new System.Windows.Forms.TextBox();
            this.cel = new System.Windows.Forms.TextBox();
            this.medidas = new System.Windows.Forms.CheckBox();
            this.alto = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.ancho = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.aggprod = new System.Windows.Forms.Button();
            this.lprod = new System.Windows.Forms.Button();
            this.elimProd = new System.Windows.Forms.Button();
            this.ldatos = new System.Windows.Forms.Button();
            this.editprod = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(277, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(173, 22);
            this.label1.TabIndex = 1;
            this.label1.Text = "Registro de Cliente";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(25, 115);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(64, 18);
            this.label2.TabIndex = 2;
            this.label2.Text = "Nombre";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(25, 159);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(124, 18);
            this.label3.TabIndex = 3;
            this.label3.Text = "Apellido Paterno";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(25, 206);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(126, 18);
            this.label4.TabIndex = 4;
            this.label4.Text = "Apellido Materno";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(25, 256);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(116, 18);
            this.label5.TabIndex = 5;
            this.label5.Text = "Numero Celular";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(25, 75);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(72, 18);
            this.label7.TabIndex = 7;
            this.label7.Text = "IDCliente";
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Location = new System.Drawing.Point(246, 302);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(299, 95);
            this.listBox1.TabIndex = 8;
            // 
            // enviar
            // 
            this.enviar.Location = new System.Drawing.Point(224, 415);
            this.enviar.Name = "enviar";
            this.enviar.Size = new System.Drawing.Size(113, 23);
            this.enviar.TabIndex = 9;
            this.enviar.Text = "Confirmar pedido";
            this.enviar.UseVisualStyleBackColor = true;
            this.enviar.Click += new System.EventHandler(this.enviar_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.blanco);
            this.groupBox1.Controls.Add(this.negro);
            this.groupBox1.Controls.Add(this.natural);
            this.groupBox1.ForeColor = System.Drawing.Color.White;
            this.groupBox1.Location = new System.Drawing.Point(427, 131);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(132, 93);
            this.groupBox1.TabIndex = 10;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Color";
            // 
            // blanco
            // 
            this.blanco.AutoSize = true;
            this.blanco.Location = new System.Drawing.Point(6, 68);
            this.blanco.Name = "blanco";
            this.blanco.Size = new System.Drawing.Size(58, 17);
            this.blanco.TabIndex = 2;
            this.blanco.TabStop = true;
            this.blanco.Text = "Blanco";
            this.blanco.UseVisualStyleBackColor = true;
            this.blanco.CheckedChanged += new System.EventHandler(this.blanco_CheckedChanged);
            // 
            // negro
            // 
            this.negro.AutoSize = true;
            this.negro.Location = new System.Drawing.Point(6, 45);
            this.negro.Name = "negro";
            this.negro.Size = new System.Drawing.Size(54, 17);
            this.negro.TabIndex = 1;
            this.negro.TabStop = true;
            this.negro.Text = "Negro";
            this.negro.UseVisualStyleBackColor = true;
            this.negro.CheckedChanged += new System.EventHandler(this.negro_CheckedChanged);
            // 
            // natural
            // 
            this.natural.AutoSize = true;
            this.natural.Location = new System.Drawing.Point(6, 19);
            this.natural.Name = "natural";
            this.natural.Size = new System.Drawing.Size(59, 17);
            this.natural.TabIndex = 0;
            this.natural.TabStop = true;
            this.natural.Text = "Natural";
            this.natural.UseVisualStyleBackColor = true;
            this.natural.CheckedChanged += new System.EventHandler(this.natural_CheckedChanged);
            // 
            // producto
            // 
            this.producto.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.producto.FormattingEnabled = true;
            this.producto.Items.AddRange(new object[] {
            "Ventana",
            "Puerta Comercial",
            "Puerta de Baño",
            "Barandal",
            "Espejo",
            "Espejo Led"});
            this.producto.Location = new System.Drawing.Point(427, 86);
            this.producto.Name = "producto";
            this.producto.Size = new System.Drawing.Size(132, 21);
            this.producto.TabIndex = 11;
            this.producto.SelectedIndexChanged += new System.EventHandler(this.producto_SelectedIndexChanged);
            // 
            // idcliente
            // 
            this.idcliente.Location = new System.Drawing.Point(103, 75);
            this.idcliente.Name = "idcliente";
            this.idcliente.Size = new System.Drawing.Size(127, 20);
            this.idcliente.TabIndex = 12;
            // 
            // nombre
            // 
            this.nombre.Location = new System.Drawing.Point(103, 116);
            this.nombre.Name = "nombre";
            this.nombre.Size = new System.Drawing.Size(142, 20);
            this.nombre.TabIndex = 13;
            // 
            // apaterno
            // 
            this.apaterno.Location = new System.Drawing.Point(170, 159);
            this.apaterno.Name = "apaterno";
            this.apaterno.Size = new System.Drawing.Size(145, 20);
            this.apaterno.TabIndex = 14;
            // 
            // amaterno
            // 
            this.amaterno.Location = new System.Drawing.Point(170, 207);
            this.amaterno.Name = "amaterno";
            this.amaterno.Size = new System.Drawing.Size(145, 20);
            this.amaterno.TabIndex = 15;
            // 
            // cel
            // 
            this.cel.Location = new System.Drawing.Point(170, 254);
            this.cel.Name = "cel";
            this.cel.Size = new System.Drawing.Size(145, 20);
            this.cel.TabIndex = 16;
            // 
            // medidas
            // 
            this.medidas.AutoSize = true;
            this.medidas.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.medidas.ForeColor = System.Drawing.Color.White;
            this.medidas.Location = new System.Drawing.Point(635, 256);
            this.medidas.Name = "medidas";
            this.medidas.Size = new System.Drawing.Size(130, 22);
            this.medidas.TabIndex = 17;
            this.medidas.Text = "Tiene medidas";
            this.medidas.UseVisualStyleBackColor = true;
            // 
            // alto
            // 
            this.alto.Location = new System.Drawing.Point(694, 302);
            this.alto.Name = "alto";
            this.alto.Size = new System.Drawing.Size(80, 20);
            this.alto.TabIndex = 19;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(603, 302);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(70, 18);
            this.label6.TabIndex = 18;
            this.label6.Text = "Alto (cm)";
            // 
            // ancho
            // 
            this.ancho.Location = new System.Drawing.Point(694, 345);
            this.ancho.Name = "ancho";
            this.ancho.Size = new System.Drawing.Size(80, 20);
            this.ancho.TabIndex = 21;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(603, 345);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(87, 18);
            this.label8.TabIndex = 20;
            this.label8.Text = "Ancho (cm)";
            // 
            // aggprod
            // 
            this.aggprod.Location = new System.Drawing.Point(622, 384);
            this.aggprod.Name = "aggprod";
            this.aggprod.Size = new System.Drawing.Size(113, 23);
            this.aggprod.TabIndex = 22;
            this.aggprod.Text = "Agregar Producto";
            this.aggprod.UseVisualStyleBackColor = true;
            this.aggprod.Click += new System.EventHandler(this.aggprod_Click);
            // 
            // lprod
            // 
            this.lprod.Location = new System.Drawing.Point(28, 359);
            this.lprod.Name = "lprod";
            this.lprod.Size = new System.Drawing.Size(113, 23);
            this.lprod.TabIndex = 23;
            this.lprod.Text = "Limpiar Productos";
            this.lprod.UseVisualStyleBackColor = true;
            this.lprod.Click += new System.EventHandler(this.lprod_Click);
            // 
            // elimProd
            // 
            this.elimProd.Location = new System.Drawing.Point(475, 415);
            this.elimProd.Name = "elimProd";
            this.elimProd.Size = new System.Drawing.Size(113, 23);
            this.elimProd.TabIndex = 24;
            this.elimProd.Text = "Eliminar Producto";
            this.elimProd.UseVisualStyleBackColor = true;
            this.elimProd.Click += new System.EventHandler(this.elimProd_Click);
            // 
            // ldatos
            // 
            this.ldatos.Location = new System.Drawing.Point(28, 315);
            this.ldatos.Name = "ldatos";
            this.ldatos.Size = new System.Drawing.Size(113, 23);
            this.ldatos.TabIndex = 25;
            this.ldatos.Text = "Limpiar Datos";
            this.ldatos.UseVisualStyleBackColor = true;
            this.ldatos.Click += new System.EventHandler(this.ldatos_Click);
            // 
            // editprod
            // 
            this.editprod.Location = new System.Drawing.Point(356, 415);
            this.editprod.Name = "editprod";
            this.editprod.Size = new System.Drawing.Size(105, 23);
            this.editprod.TabIndex = 26;
            this.editprod.Text = "Editar Producto";
            this.editprod.UseVisualStyleBackColor = true;
            this.editprod.Click += new System.EventHandler(this.editprod_Click);
            // 
            // button13
            // 
            this.button13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(37)))), ((int)(((byte)(38)))));
            this.button13.BackgroundImage = global::Registro.Properties.Resources.Atras_blanca;
            this.button13.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.button13.FlatAppearance.BorderSize = 0;
            this.button13.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button13.Location = new System.Drawing.Point(28, 10);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(54, 49);
            this.button13.TabIndex = 27;
            this.button13.UseVisualStyleBackColor = false;
            this.button13.Click += new System.EventHandler(this.button13_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(578, 35);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(169, 172);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // Registro
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(37)))), ((int)(((byte)(38)))));
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.button13);
            this.Controls.Add(this.editprod);
            this.Controls.Add(this.ldatos);
            this.Controls.Add(this.elimProd);
            this.Controls.Add(this.lprod);
            this.Controls.Add(this.aggprod);
            this.Controls.Add(this.ancho);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.alto);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.medidas);
            this.Controls.Add(this.cel);
            this.Controls.Add(this.amaterno);
            this.Controls.Add(this.apaterno);
            this.Controls.Add(this.nombre);
            this.Controls.Add(this.idcliente);
            this.Controls.Add(this.producto);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.enviar);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "Registro";
            this.Text = "Registro";
            this.Load += new System.EventHandler(this.Registro_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Button enviar;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton blanco;
        private System.Windows.Forms.RadioButton negro;
        private System.Windows.Forms.RadioButton natural;
        private System.Windows.Forms.ComboBox producto;
        private System.Windows.Forms.TextBox idcliente;
        private System.Windows.Forms.TextBox nombre;
        private System.Windows.Forms.TextBox apaterno;
        private System.Windows.Forms.TextBox amaterno;
        private System.Windows.Forms.TextBox cel;
        private System.Windows.Forms.CheckBox medidas;
        private System.Windows.Forms.TextBox alto;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox ancho;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button aggprod;
        private System.Windows.Forms.Button lprod;
        private System.Windows.Forms.Button elimProd;
        private System.Windows.Forms.Button ldatos;
        private System.Windows.Forms.Button editprod;
        private Button button13;
    }
}