﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace TablaClientes
{
    public partial class TablaClientes : Form
    {
        private Form menuRef;

        public TablaClientes(Form menu)
        {
            InitializeComponent();
            this.Load += TablaClientes_Load;
            this.menuRef = menu;
        }
        private void TablaClientes_Load(object sender, EventArgs e)
        {
            if (dataGridView1.Rows.Count == 0) // Para evitar agregar duplicados
            {
                AgregarCliente("1", "Ana López Ruiz", "6621234567", "Ventana - natural, Espejo Led - blanca");
                AgregarCliente("2", "Carlos Pérez Soto", "6649876543", "Puerta de Baño - blanca, Barandal - negra");
                AgregarCliente("3", "Diana Torres Vega", "6861112233", "Ventana - negra, Puerta Comercial - natural");
                AgregarCliente("4", "Luis Martínez Ramírez", "6567654321", "Espejo - natural, Espejo Led - blanca, Barandal - negra");
                AgregarCliente("5", "Sofía Gómez Díaz", "6678889900", "Ventana - blanca, Puerta Comercial - negra");
            }
        }


        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            if (e.CloseReason == CloseReason.UserClosing)
            {
                e.Cancel = true; // evita cierre con la X
            }
            base.OnFormClosing(e);
        }

        public void AgregarCliente(string id, string nombreCompleto, string celular, string productos)
        {
            dataGridView1.Rows.Add(id, nombreCompleto, celular, productos);
        }

        private void btnVolver_Click(object sender, EventArgs e)
        {
            menuRef.Show();
            this.Hide(); 
        }
    }
}
