﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace Registro
{
    public partial class Registro : Form
    {
        private Form menuRef;
        private TablaClientes.TablaClientes tablaForm;

        public Registro()
        {
            InitializeComponent();
            InicializarValidaciones();
        }

        public Registro(Form menu, TablaClientes.TablaClientes tabla)
        {
            InitializeComponent();
            this.menuRef = menu;
            this.tablaForm = tabla;
        }
        private void InicializarValidaciones()
        {
            // Validaciones de entrada
            idcliente.KeyPress += SoloNumeros_KeyPress;
            cel.KeyPress += SoloNumeros_KeyPress;
            alto.KeyPress += SoloNumeros_KeyPress;
            ancho.KeyPress += SoloNumeros_KeyPress;

            nombre.KeyPress += SoloLetras_KeyPress;
            apaterno.KeyPress += SoloLetras_KeyPress;
            amaterno.KeyPress += SoloLetras_KeyPress;

            producto.SelectedIndexChanged += producto_SelectedIndexChanged;
            medidas.CheckedChanged += medidas_CheckedChanged;

            natural.CheckedChanged += (s, e) => MostrarImagen();
            negro.CheckedChanged += (s, e) => MostrarImagen();
            blanco.CheckedChanged += (s, e) => MostrarImagen();

            alto.Enabled = false;
            ancho.Enabled = false;
            label6.Enabled = false;
            label8.Enabled = false;

            natural.Checked = true;
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            if (e.CloseReason == CloseReason.UserClosing)
                e.Cancel = true;

            base.OnFormClosing(e);
        }

        private void SoloNumeros_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                MessageBox.Show("Solo se permiten números.", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                e.Handled = true;
            }
        }

        private void SoloLetras_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsLetter(e.KeyChar) && e.KeyChar != ' ')
            {
                MessageBox.Show("Solo se permiten letras.", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                e.Handled = true;
            }
        }

        private void ldatos_Click(object sender, EventArgs e)
        {
            idcliente.Clear(); nombre.Clear(); apaterno.Clear(); amaterno.Clear(); cel.Clear();
            alto.Clear(); ancho.Clear(); medidas.Checked = false;
        }

        private void lprod_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
        }

        private void elimProd_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex >= 0)
                listBox1.Items.RemoveAt(listBox1.SelectedIndex);
            else
                MessageBox.Show("Selecciona un producto para eliminar.", "Advertencia");
        }

        private void editprod_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex < 0)
            {
                MessageBox.Show("Selecciona un producto para editar.", "Advertencia");
                return;
            }

            aggprod_Click(sender, e);
            listBox1.Items.RemoveAt(listBox1.SelectedIndex);
        }

        private void aggprod_Click(object sender, EventArgs e)
        {
            if (producto.SelectedIndex == -1)
            {
                MessageBox.Show("Selecciona un producto.", "Error");
                return;
            }

            string prod = producto.SelectedItem.ToString();
            string color = "";

            if (groupBox1.Enabled) // Solo si no es espejo
            {
                if (natural.Checked) color = "natural";
                else if (negro.Checked) color = "negra";
                else if (blanco.Checked) color = "blanca";
            }

            string desc = string.IsNullOrEmpty(color) ? prod : $"{prod} - {color}";

            if (medidas.Checked)
            {
                if (string.IsNullOrWhiteSpace(alto.Text) || string.IsNullOrWhiteSpace(ancho.Text))
                {
                    MessageBox.Show("Especifica alto y ancho.", "Error");
                    return;
                }
                desc += $" ({alto.Text}x{ancho.Text} cm)";
            }

            listBox1.Items.Add(desc);
        }

        private void blanco_CheckedChanged(object sender, EventArgs e)
        {
            if (blanco.Checked)
                MostrarImagen();
        }

        private void negro_CheckedChanged(object sender, EventArgs e)
        {
            if (negro.Checked)
                MostrarImagen();
        }

        private void natural_CheckedChanged(object sender, EventArgs e)
        {
            if (natural.Checked)
                MostrarImagen();
        }
        private void medidas_CheckedChanged(object sender, EventArgs e)
        {
            bool active = medidas.Checked;
            alto.Enabled = active;
            ancho.Enabled = active;
            label6.Enabled = active;
            label8.Enabled = active;

            if (!active)
            {
                alto.Clear();
                ancho.Clear();
            }
        }


        private void producto_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (producto.SelectedItem == null) return;

            natural.Checked = true;

            string prod = producto.SelectedItem.ToString();
            blanco.Enabled = !(prod.Contains("Baño") || prod.Contains("Barandal"));
            groupBox1.Enabled = !(prod.Contains("Espejo"));

            MostrarImagen();
        }

        private void MostrarImagen()
        {
            if (producto.SelectedIndex == -1)
            {
                pictureBox1.Image = null;
                return;
            }

            string prod = producto.SelectedItem.ToString().ToLower();

            prod = prod.Replace("puerta comercial", "comercial")
                       .Replace("puerta de baño", "bano")
                       .Replace("espejo led", "espejo_led")
                       .Replace(" ", "_");

            string color = "";

            if (groupBox1.Enabled)
            {
                if (natural.Checked) color = "natural";
                else if (negro.Checked) color = "negro";
                else if (blanco.Checked) color = "blanca";
            }

            string key = string.IsNullOrEmpty(color) ? prod : $"{prod}_{color}";

            try
            {
                pictureBox1.Image = (Image)Properties.Resources.ResourceManager.GetObject(key);
            }
            catch
            {
                pictureBox1.Image = null;
            }
        }

        private void enviar_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(idcliente.Text) ||
                string.IsNullOrWhiteSpace(nombre.Text) ||
                string.IsNullOrWhiteSpace(apaterno.Text) ||
                string.IsNullOrWhiteSpace(amaterno.Text) ||
                string.IsNullOrWhiteSpace(cel.Text))
            {
                MessageBox.Show("Debes completar todos los campos de datos del cliente.", "Error");
                return;
            }

            if (listBox1.Items.Count == 0)
            {
                MessageBox.Show("Debes agregar al menos un producto.", "Error");
                return;
            }

            string id = idcliente.Text.Trim();
            string nombreCompleto = $"{nombre.Text.Trim()} {apaterno.Text.Trim()} {amaterno.Text.Trim()}";
            string celular = cel.Text.Trim();

            List<string> productos = new List<string>();
            foreach (var item in listBox1.Items)
                productos.Add(item.ToString());

            string productosTexto = string.Join(", ", productos);

            foreach (DataGridViewRow row in tablaForm.dataGridView1.Rows)
            {
                if (row.Cells[0].Value != null && row.Cells[0].Value.ToString() == id)
                {
                    MessageBox.Show("Este ID de cliente ya está registrado.", "Duplicado", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
            }

            tablaForm.AgregarCliente(id, nombreCompleto, celular, productosTexto);
            MessageBox.Show("Pedido confirmado y agregado a la tabla.", "Confirmación", MessageBoxButtons.OK, MessageBoxIcon.Information);

            ldatos_Click(sender, e);
            lprod_Click(sender, e);
            producto.SelectedIndex = -1;
            groupBox1.Enabled = true;
            blanco.Enabled = true;
            natural.Checked = true;
        }

        private void button13_Click(object sender, EventArgs e)
        {
            menuRef.Show();
            this.Dispose();
        }
        private void Registro_Load(object sender, EventArgs e)
        {
            // Reasignar validaciones por si se pierden
            idcliente.KeyPress += SoloNumeros_KeyPress;
            cel.KeyPress += SoloNumeros_KeyPress;
            alto.KeyPress += SoloNumeros_KeyPress;
            ancho.KeyPress += SoloNumeros_KeyPress;

            nombre.KeyPress += SoloLetras_KeyPress;
            apaterno.KeyPress += SoloLetras_KeyPress;
            amaterno.KeyPress += SoloLetras_KeyPress;

            producto.SelectedIndexChanged += producto_SelectedIndexChanged;
            medidas.CheckedChanged += medidas_CheckedChanged;
            medidas.Checked = false;
            medidas_CheckedChanged(null, null);
        }
    }
}
