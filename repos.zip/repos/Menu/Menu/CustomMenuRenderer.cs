﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.Windows.Forms;

public class CustomMenuRenderer : ToolStripProfessionalRenderer
{
    public CustomMenuRenderer() : base(new CustomColorTable()) { }

    protected override void OnRenderMenuItemBackground(ToolStripItemRenderEventArgs e)
    {
        Color bgColor;

        if (e.Item.Selected)
            bgColor = Color.FromArgb(50, 50, 50);  // Hover
        else
            bgColor = Color.FromArgb(36, 37, 38);  // Fondo base

        using (SolidBrush brush = new SolidBrush(bgColor))
        {
            e.Graphics.FillRectangle(brush, e.Item.ContentRectangle);
        }
    }

    protected override void OnRenderItemText(ToolStripItemTextRenderEventArgs e)
    {
        e.TextColor = Color.White;
        base.OnRenderItemText(e);
    }
}

public class CustomColorTable : ProfessionalColorTable
{
    public override Color ToolStripDropDownBackground => Color.FromArgb(36, 37, 38);
    public override Color MenuItemSelected => Color.FromArgb(50, 50, 50);
    public override Color MenuItemSelectedGradientBegin => Color.FromArgb(50, 50, 50);
    public override Color MenuItemSelectedGradientEnd => Color.FromArgb(50, 50, 50);
    public override Color MenuItemBorder => Color.Black;
}

