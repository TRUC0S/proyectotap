﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;
using TablaClientes;

namespace grafica
{
    public partial class Grafica : Form
    {
        private Form menuRef;
        private TablaClientes.TablaClientes tablaForm;
        public Grafica()
        {
            InitializeComponent();
        }
        public Grafica(Form menu, TablaClientes.TablaClientes tabla)
        {
            if (menu == null || tabla == null)
            {
                MessageBox.Show("Este formulario debe ser abierto desde el menú.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.Close(); // O: this.Dispose();
                return;
            }

            InitializeComponent();
            menuRef = menu;
            tablaForm = tabla;
        }


        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            if (e.CloseReason == CloseReason.UserClosing)
            {
                e.Cancel = true; // Cancela el cierre
            }
            base.OnFormClosing(e);
        }

        private void Grafica_Load(object sender, EventArgs e)
        {
            Dictionary<string, int> conteo = new Dictionary<string, int>
            {
                { "Ventana", 0 },
                { "P.Comercial", 0 },
                { "P.Baño", 0 },
                { "Barandal", 0 },
                { "Espejos", 0 }
            };

            foreach (DataGridViewRow fila in tablaForm.dataGridView1.Rows)
            {
                if (fila.Cells["colProductos"].Value == null) continue;

                string productos = fila.Cells["colProductos"].Value.ToString().ToLower();
                string[] items = productos.Split(',');

                foreach (string item in items)
                {
                    string p = item.Trim();
                    if (p.Contains("ventana"))
                        conteo["Ventana"]++;
                    else if (p.Contains("comercial"))
                        conteo["P.Comercial"]++;
                    else if (p.Contains("baño"))
                        conteo["P.Baño"]++;
                    else if (p.Contains("barandal"))
                        conteo["Barandal"]++;
                    else if (p.Contains("espejo"))
                        conteo["Espejos"]++;
                }
            }

            GRAFICAR.Series.Clear();
            Series serie = new Series("Productos Vendidos")
            {
                ChartType = SeriesChartType.Column,
                IsValueShownAsLabel = true,
                Color = Color.Red
            };

            foreach (var kvp in conteo)
                serie.Points.AddXY(kvp.Key, kvp.Value);

            GRAFICAR.Series.Add(serie);
            // Fondo del gráfico
            GRAFICAR.BackColor = Color.FromArgb(36, 37, 38);
            GRAFICAR.ChartAreas[0].BackColor = Color.FromArgb(36, 37, 38);

            // Títulos y etiquetas
            GRAFICAR.Titles[0].ForeColor = Color.White;
            GRAFICAR.ChartAreas[0].AxisX.LabelStyle.ForeColor = Color.White;
            GRAFICAR.ChartAreas[0].AxisY.LabelStyle.ForeColor = Color.White;
            GRAFICAR.ChartAreas[0].AxisX.TitleForeColor = Color.White;
            GRAFICAR.ChartAreas[0].AxisY.TitleForeColor = Color.White;

            // Leyenda
            GRAFICAR.Legends[0].ForeColor = Color.White;
            GRAFICAR.Legends[0].BackColor = Color.FromArgb(36, 37, 38);

            // Líneas de ejes
            GRAFICAR.ChartAreas[0].AxisX.MajorGrid.Enabled = false;  
            GRAFICAR.ChartAreas[0].AxisY.MajorGrid.LineColor = Color.White; 

            // Ejes
            GRAFICAR.ChartAreas[0].AxisX.LineColor = Color.White;
            GRAFICAR.ChartAreas[0].AxisY.LineColor = Color.White;
            serie.LabelForeColor = Color.White; // Números encima de las barras
            GRAFICAR.Titles.Clear();
            GRAFICAR.Titles.Add("Ventas por Tipo de Producto");
            GRAFICAR.Titles.Clear();
            Title titulo = new Title("Ventas por Tipo de Producto", Docking.Top, new Font("Arial", 12, FontStyle.Regular), Color.White);
            GRAFICAR.Titles.Add(titulo);

        }

        private void btnVolver_Click(object sender, EventArgs e)
        {
            menuRef.Show();
            this.Dispose();
        }
    }
}
