﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Menu
{
    public partial class Aplicacion : Form
    {
        private Form menuRef;

        // Constructor que recibe la referencia al formulario principal
        public Aplicacion(Form menu)
        {
            InitializeComponent();
            this.menuRef = menu;
        }

        // Bloquea el cierre con la "X"
        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            if (e.CloseReason == CloseReason.UserClosing)
            {
                e.Cancel = true; // impide cerrar con la X
            }
            base.OnFormClosing(e);
        }

        // Botón "Atrás"
        private void button1_Click(object sender, EventArgs e)
        {
            menuRef.Show();   // muestra el formulario Menu
            this.Dispose();   // libera y cierra Aplicacion
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
    }
}
