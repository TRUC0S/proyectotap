﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Registro;
using TablaClientes;
using grafica;

namespace Menu
{
    public partial class Menu : Form

    {
        private TablaClientes.TablaClientes tablaForm;

        public Menu()
        {
            InitializeComponent();
            tablaForm = new TablaClientes.TablaClientes(this); // Pasamos referencia a este menú
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            menuStrip1.Renderer = new CustomMenuRenderer();
            menuStrip1.ForeColor = Color.White;
        }

        private void nosotrosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Nosotros n = new Nosotros(this);
            n.Show();
            this.Hide();
        }

        private void aplicacionToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Aplicacion a = new Aplicacion(this);
            a.Show();
            this.Hide();
        }

        private void productToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Productos p = new Productos(this);
            p.Show();
            this.Hide();
        }

        private void añadirVentaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Registro.Registro reg = new Registro.Registro(this, tablaForm);
            reg.Show();
            this.Hide();
        }

        private void clientesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            tablaForm.Show();
            this.Hide();
        }

        private void ventasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Grafica g = new Grafica(this, tablaForm);
            g.Show();
            this.Hide();
        }
    }
}
